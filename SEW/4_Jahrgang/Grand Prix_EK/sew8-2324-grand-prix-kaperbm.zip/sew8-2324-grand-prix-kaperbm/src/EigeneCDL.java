/**
 * Eigener Countdown
 * @author Kacper Bohaczyk
 * @version 17.05.2024
 */
class EigeneCDL {
    private int countdown;

    /**
     * Gegebener Countdown im Konstruktor setzten
     * @param countdown Größe vom Countdown
     */
    EigeneCDL(int countdown) {
        this.countdown = countdown;
    }

    EigeneCDL() {
        this(1);
    }

    /**
     * Lässt die Threads warten bis der countdown abgelaufen ist
     * @throws InterruptedException Abbruch des Threads
     */
    synchronized void await() throws InterruptedException {
        while (countdown > 0) {
            wait();
        }
    }

    /**
     * Der Countdown wird rutergezählt
     */
    synchronized void countDown() {
        countdown--;
        if (countdown == 0) {
            notifyAll();
        }
    }
}
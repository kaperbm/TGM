class Reading(object):
    """
    Messwert wird als Daten dargestellt
    :Date: 15-05-2024
    :Author: Kacper Bohaczyk
    """

    def __init__(self, temperature: float, pressure: float):
        self._temperature = temperature
        self._pressure = pressure

    def _get_temperature(self) -> float:
        return self._temperature

    temperature = property(_get_temperature)

    def _get_pressure(self) -> float:
        return self._pressure

    pressure = property(_get_pressure)


if __name__ == "__main__":
    reading = Reading(5.0, 1000.0)
    try:
        reading.temperature = 30.0
    except AttributeError as e:
        print("Versuch Temperatur zu setzten: ", e)
    try:
        reading.pressure = 1060.5
    except AttributeError as e:
        print("Versuch Druck zu setzen: ", e)
    print(f"Aktuelle Temperatur: {reading.temperature}")
    print(f"Aktuelle Pressure: {reading.pressure}")

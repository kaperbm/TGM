import Reading
import random


class Sensor(object):
    """
    Ein Sensor der random Daten liest
    :Date: 09-05-2024
    :Author: Kacper Boahczyk
    """

    def get_reading(self) -> Reading:
        return Reading.Reading(round(random.uniform(-15.0, 60.0), 2), round(random.uniform(750.0, 1250.0), 2))


if __name__ == "__main__":
    sensor = Sensor()
    reading = sensor.get_reading()
    print(f"Aktuelle Temperatur: {reading.temperature}")
    print(f"Aktuelle Pressure: {reading.pressure}")

import Reading
import Sensor


class Weatherstation(object):
    """
    10 Temperaturen und Pressures werden gelesen
    :Date: 15-05-2024
    :Author: Kacper Bohaczyk
    """

    def __init__(self, sensor: Sensor):
        self._sensor = sensor
        self._readings: list[Reading] = []

    def record_reading(self):
        reading: Reading = self._sensor.get_reading()
        self._readings.append(reading)
        if len(self._readings) > 10:
            self._readings.pop(0)

    def avg_temperature(self) -> float:
        if len(self._readings) != 10:
            raise ValueError("Unter 10 Werte werden nicht akzeptiert!")
        return round(sum([reading.temperature for reading in self._readings]) / len(self._readings), 2)

    def avg_pressure(self) -> float:
        if len(self._readings) != 10:
            raise ValueError("Unter 10 Werte werden nicht akzeptiert!")
        return round(sum([reading.pressure for reading in self._readings]) / len(self._readings), 2)


if __name__ == "__main__":
    sensor = Sensor.Sensor()
    weatherstation = Weatherstation(sensor)
    try:
        weatherstation.avg_temperature()
    except ValueError as e:
        print("Unter 10 Werte: ", e)
    try:
        weatherstation.avg_pressure()
    except ValueError as e:
        print("Unter 10 Werte: ", e)
    for _ in range(10):
        weatherstation.record_reading()
    print(f"Durschnitt Temp: {weatherstation.avg_temperature()}")
    print(f"Durchschnitt Pressure: {weatherstation.avg_pressure()}")

/**
 * OrderListen Observer
 * @author Kacper Bohaczyk
 * @version 2024-01-11
 */
interface Observer{
    /**
     * Updaten des Observers
     */
    void update();
}
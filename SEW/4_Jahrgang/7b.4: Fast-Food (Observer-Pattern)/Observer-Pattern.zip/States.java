/**
 * Enum Status
 * @author Kacper Bohaczyk
 * @version 2024-01-11
 */
enum States {
    NEU, IN_BEARBEITUNG, BEREIT, ABGEHOLT
}
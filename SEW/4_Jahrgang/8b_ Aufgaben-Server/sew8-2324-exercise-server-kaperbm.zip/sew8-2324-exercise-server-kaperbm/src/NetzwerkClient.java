import java.io.*;
import java.net.*;

/**
 * Netzwerkclient, der auf einen Server zugreift.
 * @author kacper Bohaczyk
 * @version 15-05-2024
 */
public class NetzwerkClient {

    /**
     * Hauptmethode, die eine Verbindung zum Server herstellt und Anfragen beantwortet.
     * @param args Enthält die IP-Adresse und die Portnummer des Servers.
     */
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("FALSCHE ANZAHL AN ARGUMENTEN!");
            return;
        }

        String serverAdresse = args[0];
        int portNummer;
        try {
            portNummer = Integer.parseInt(args[1]);
        } catch (NumberFormatException e) {
            System.out.println("UNGUELTIGE PORTNUMMER ANGEGEBEN!");
            return;
        }

        try (
                Socket verbindung = new Socket(serverAdresse, portNummer);
                PrintWriter serverAusgabe = new PrintWriter(verbindung.getOutputStream(), true);
                BufferedReader serverEingabe = new BufferedReader(new InputStreamReader(verbindung.getInputStream()));
                BufferedReader benutzerEingabe = new BufferedReader(new InputStreamReader(System.in))
        ) {
            String serverNachricht;

            while ((serverNachricht = serverEingabe.readLine()) != null) {
                System.out.println("Nachricht vom Server: " + serverNachricht);

                if (serverNachricht.contains("?")) {
                    String antwort = benutzerEingabe.readLine();
                    serverAusgabe.println(antwort);
                }
            }


        } catch (UnknownHostException e) {
            System.err.println("Unbekannte Adresse: " + serverAdresse);
        } catch (IOException e) {
            System.err.println("I/O-Fehler beim Zugriff auf den Server");
        }
    }
}

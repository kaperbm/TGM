import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;


/**
 * Server, der Verbindungen von Clients akzeptiert und Aufgaben verteilt.
 * @author kacper Bohaczyk
 * @version 15-05-2024
 */
public class AuftragsServer {

    static final int MAX_THREADS = 10; // Maximale Anzahl der Threads
    private static String[] fragen;
    private static String[] antworten;

    /**
     * Startet den Server auf dem angegebenen Port
     * @param args Enthält die Portnummer
     */
    public static void main(String[] args) {
        ExecutorService threadPool = Executors.newFixedThreadPool(MAX_THREADS);
        if (args.length != 1) {
            System.out.println("FALSCHE ANZAHL AN ARGUMENTEN!");
            return;
        }

        int portNummer;
        try {
            portNummer = Integer.parseInt(args[0]);
        } catch (NumberFormatException e) {
            System.out.println("UNGUELTIGE PORTNUMMER ANGEGEBEN!");
            return;
        }

        try (ServerSocket serverSocket = new ServerSocket(portNummer)) {
            System.out.println("Server läuft auf Port: " + portNummer);
            ladeFragenUndAntworten("src/FragenUndAntworten.txt");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Verbindung zu neuem Client: " + clientSocket);
                Runnable aufgabe = new ClientHandler(clientSocket, fragen, antworten);
                threadPool.submit(aufgabe);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            threadPool.shutdown();
        }
    }

    /**
     * Lädt Fragen und Antworten aus einer Datei.
     * @param dateiPfad Pfad zur Datei mit Fragen und Antworten
     */
    private static void ladeFragenUndAntworten(String dateiPfad) {
        List<String> fragenListe = new ArrayList<>();
        List<String> antwortenListe = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(dateiPfad))) {
            String zeile;
            while ((zeile = reader.readLine()) != null) {
                String[] teile = zeile.split("\\:", 2);
                if (teile.length == 2) {
                    fragenListe.add(teile[0].trim());
                    antwortenListe.add(teile[1].trim());
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        fragen = fragenListe.toArray(new String[0]);
        antworten = antwortenListe.toArray(new String[0]);
    }
}

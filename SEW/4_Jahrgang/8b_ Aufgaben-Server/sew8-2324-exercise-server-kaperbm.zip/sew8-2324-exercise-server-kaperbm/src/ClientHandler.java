import java.io.*;
        import java.net.*;
        import java.util.*;

/**
 * Handhabung der Fragenbeantwortung und Steuerung des Client-Threads.
 * @author kacper Bohaczyk
 * @date 15-05-2024
 */
public class ClientHandler implements Runnable {
    private final Socket socket;
    private List<String> fragen;
    private List<String> antworten;

    /**
     * Konstruktor für den ClientHandler
     * @param socket Client-Socket
     * @param fragen Array der Fragen
     * @param antworten Array der Antworten
     */
    public ClientHandler(Socket socket, String[] fragen, String[] antworten) {
        this.socket = socket;
        this.fragen = new ArrayList<>(List.of(fragen)); // Kopiert die Liste der Fragen
        this.antworten = new ArrayList<>(List.of(antworten)); // Kopiert die Liste der Antworten
    }

    /**
     * Führt das Quiz für den Client durch.
     */
    @Override
    public void run() {
        try (
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()))
        ) {
            Random zufallsgenerator = new Random();
            int punktzahl = 0;

            for (int i = 0; i < 3; i++) {
                int zufallsIndex = zufallsgenerator.nextInt(fragen.size());
                String frage = fragen.remove(zufallsIndex); // Entfernt die Frage
                String antwort = antworten.remove(zufallsIndex); // Entfernt die Antwort

                output.println(frage);
                String clientAntwort = input.readLine();

                if (clientAntwort != null && clientAntwort.equals(antwort)) {
                    output.println("Richtig!");
                    punktzahl++;
                } else {
                    output.println("Falsch! Richtige Antwort: \"" + antwort + "\"");
                }
            }

            output.println(punktzahl + "/3 Fragen richtig beantwortet");
            socket.close();
            System.out.println("Client getrennt: " + socket);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


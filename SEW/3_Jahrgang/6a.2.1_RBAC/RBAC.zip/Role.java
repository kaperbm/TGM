package kbohaczyk;

/**
 * kbohaczyk.Role Interface
 * @author Kacper Boahczyk
 * @version 27-03-2023
 */
public interface Role {
    String getName();
    String getDescription();
}
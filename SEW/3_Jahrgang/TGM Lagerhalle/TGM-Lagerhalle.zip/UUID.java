/**
 * @author Kacper Bohaczyk
 * @version 13-04-2023
 */
public class UUID {

    private int id;

    public UUID(int id) {
        this.id = id;
    }
}

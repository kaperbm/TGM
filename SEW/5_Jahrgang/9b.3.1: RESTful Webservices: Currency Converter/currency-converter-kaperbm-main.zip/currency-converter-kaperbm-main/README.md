# Währungsrechner README

**author** Kacper Bohaczyk
**version** 


## Projektübersicht

Dieses Projekt stellt einen einfachen **Währungsumrechner** dar, der eine GUI für die Umrechnung von Währungen unter Verwendung der [API Layer](https://apilayer.com/) zur Verfügung stellt. Die Anwendung besteht aus drei Hauptkomponenten:

- **Model**: Diese Klasse verwaltet die Kommunikation mit der API und stellt die Umrechnungslogik bereit.
- **View**: Diese Klasse erzeugt die Benutzeroberfläche (GUI) mit PyQt6 und zeigt die Ergebnisse an.
- **Controller**: Die Controller-Klasse verbindet die Model- und View-Komponenten, reagiert auf Benutzerinteraktionen und aktualisiert die View mit den Ergebnissen.

## Komponenten

### 1. `model.py`
Die `Model`-Klasse stellt die Logik für die Umrechnung von Währungen zur Verfügung, indem sie Anfragen an die externe API sendet.

#### Hauptfunktionen:
- **convert**: Sendet eine Anfrage an die API zur Umrechnung eines Betrags von einer Basiswährung in eine Zielwährung. Die Funktion gibt die Antwort von der API zurück oder gibt eine Fehlermeldung aus, falls die Anfrage fehlschlägt.

### 2. `view.py`
Die `View`-Klasse stellt die Benutzeroberfläche (GUI) mithilfe von PyQt6 zur Verfügung. Sie enthält Eingabefelder für den Betrag, die Basiswährung und die Zielwährungen sowie Schaltflächen zum Umrechnen und Zurücksetzen.

#### Hauptfunktionen:
- **init_ui**: Initialisiert das Benutzeroberflächenlayout, einschließlich der Eingabefelder und Schaltflächen.
- **setLayout**: Setzt das Layout der GUI.

### 3. `controller.py`
Die `Controller`-Klasse stellt die Verbindung zwischen der Model- und View-Komponente her. Sie reagiert auf Benutzerinteraktionen (wie Button-Klicks) und aktualisiert die View.

#### Hauptfunktionen:
- **convert_currency**: Führt die Währungsumrechnung durch, ruft die Umrechnungsfunktion im Model auf und zeigt das Ergebnis in der View an.
- **reset_fields**: Setzt alle Eingabefelder zurück und leert die Ausgabefelder.

### 4. `main.py`
Diese Datei ist der Einstiegspunkt der Anwendung und verbindet das Model, die View und den Controller. Sie startet die PyQt6-Anwendung und zeigt das Hauptfenster an.

## Funktionsweise

1. **Benutzer gibt einen Betrag, eine Basiswährung und Zielwährungen ein.**
2. **Der Benutzer klickt auf "Umrechnen".**
3. **Die Controller-Klasse ruft die Umrechnungsfunktion des Models auf.**
4. **Die View zeigt das Ergebnis der Umrechnung und das Datum der Umrechnung an.**

Die Benutzeroberfläche zeigt auch Fehlermeldungen an, falls bei der Anfrage oder Umrechnung ein Fehler auftritt.

## Anforderungen

- **Python 3.x**
- **PyQt6**: Die GUI wird mit der PyQt6-Bibliothek erstellt. Installiere PyQt6 mit:

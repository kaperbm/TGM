# Wichtige Mitteilung

Im Fach **Syt Ethik** ist die Veröffentlichung von Unterrichtsmaterialien **nicht gestattet**.

Es wurden jedoch Themen im 4. und 5. Jahrgang besprochen, unterteilt in folgende Bereiche:

## Ethik und Medien

- Datenschutz und Ethik
- Verschiedene Ansichtsweisen 
- Manipulation durch Medien
- Fake News
- Ethik in der Wissenschaft

## Technologie und Gesellschaft

- Künstliche Intelligenz und Gesellschaft
- Verantwortung im digitalen Zeitalter
- Soziale Netzwerke und deren Einfluss
- Überwachung und Privatsphäre

## Politik und Digitalisierung

- Digitale Demokratie und Partizipation
- Cybermobbing und seine Folgen
- Philosophie der Technik
- Nachhaltigkeit und Digitalisierung
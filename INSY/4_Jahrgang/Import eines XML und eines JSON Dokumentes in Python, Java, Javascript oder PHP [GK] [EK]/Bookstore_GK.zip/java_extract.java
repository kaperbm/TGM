import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.*;

public class java_extract {
    public static void main(String[] args) {
        try {
            // Dateipfad zur XML-Datei
            String file_path = "/home/kacper/Desktop/INSY/Bookstore/book_store.xml";
// XML-Datei einlesen
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new File(file_path));

            // Iteriere durch die Bücher und zeige Informationen an
            NodeList bookList = document.getElementsByTagName("book");
            for (int i = 0; i < bookList.getLength(); i++) {
                Element book = (Element) bookList.item(i);
                String category = book.getAttribute("category");
                String title = book.getElementsByTagName("title").item(0).getTextContent();
                String lang = book.getElementsByTagName("title").item(0).getAttributes().getNamedItem("lang").getTextContent();
                String author = book.getElementsByTagName("author").item(0).getTextContent();
                String year = book.getElementsByTagName("year").item(0).getTextContent();
                String price = book.getElementsByTagName("price").item(0).getTextContent();

                System.out.println("Category: " + category);
                System.out.println("Title (" + lang + "): " + title);
                System.out.println("Author: " + author);
                System.out.println("Year: " + year);
                System.out.println("Price: " + price + "\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
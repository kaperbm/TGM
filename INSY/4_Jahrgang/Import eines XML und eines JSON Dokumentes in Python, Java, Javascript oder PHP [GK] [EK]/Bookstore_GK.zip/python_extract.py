import xml.etree.ElementTree as ET

# Dateipfad zur XML-Datei
file_path = '/home/kacper/Desktop/INSY/Bookstore/book_store.xml'

# XML-Datei einlesen
tree = ET.parse(file_path)
root = tree.getroot()

# Iteriere durch die Bücher und zeige Informationen an
for book in root.findall('.//book'):
    category = book.get('category')
    title = book.find('title').text
    author = book.find('author').text
    year = book.find('year').text
    price = book.find('price').text

    print(f"Category: {category}")
    print(f"Title ({book.find('title').get('lang')}): {title}")
    print(f"Author: {author}")
    print(f"Year: {year}")
    print(f"Price: {price}\n")
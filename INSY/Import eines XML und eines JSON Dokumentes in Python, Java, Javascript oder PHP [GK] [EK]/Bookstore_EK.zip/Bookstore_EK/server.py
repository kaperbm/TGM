import json
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# Load initial data from JSON file
with open('bookstore.json', 'r') as file:
    data = json.load(file)

# Route for rendering the form and handling updates
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Handle form submission
        try:
            new_data = request.get_json(force=True)
            data['books'] = new_data['books']

            # Save updated data to the JSON file
            with open('bookstore.json', 'w') as file:
                json.dump(data, file, indent=4)

            return jsonify(success=True)

        except json.JSONDecodeError as e:
            return jsonify(success=False, error=str(e))

    # Render the form with the current data
    return render_template('index.html', data=data['books'])

if __name__ == '__main__':
    app.run(debug=True)

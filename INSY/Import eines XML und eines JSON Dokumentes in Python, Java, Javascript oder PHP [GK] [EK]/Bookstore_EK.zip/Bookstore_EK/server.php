<?php
// Lese JSON-Datei ein
$jsonData = file_get_contents(__DIR__ . '/bookstore.json');
$data = json_decode($jsonData, true);

// Überprüfe, ob das Formular gesendet wurde
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Aktualisiere die Informationen mit den Daten aus dem Formular
    $postData = json_decode(file_get_contents('php://input'), true);
    foreach ($postData['books'] as $index => $bookData) {
        $data['books'][$index] = $bookData;
    }

    // Speichere die aktualisierten Informationen in der JSON-Datei
    file_put_contents(__DIR__ . '/bookstore.json', json_encode($data, JSON_PRETTY_PRINT));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore Editor</title>
</head>
<body>

<h1>Bookstore Editor</h1>

<form method="post" action="">
    <?php foreach ($data['books'] as $index => $book): ?>
        <div>
            <label for="category<?= $index ?>">Category:</label>
            <input type="text" id="category<?= $index ?>" name="books[<?= $index ?>][category]" value="<?= $book['category'] ?>" required>
        </div>
        <div>
            <label for="title<?= $index ?>">Title:</label>
            <input type="text" id="title<?= $index ?>" name="books[<?= $index ?>][title]" value="<?= $book['title'] ?>" required>
        </div>
        <!-- Weitere Felder hier -->
        <hr>
    <?php endforeach; ?>

    <button type="submit">Speichern</button>
</form>

</body>
</html>
